from fact import factorial
__all__ = [factorial, ]
